//
//  ToDoItem.swift
//  levesqu.a1
//
//  Created by Chris Levesque on 9/6/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

//import Cocoa
import Foundation



class ToDoItem: NSObject {
   
    var itemName: String
    var completed: Bool
    var creationDate: NSDate
    
    override init(){
        itemName = " "
        completed = false
        creationDate = NSDate()
        
    }

        
    
    } 
