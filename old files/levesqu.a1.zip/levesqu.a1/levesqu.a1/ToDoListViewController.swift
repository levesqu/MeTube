//
//  ToDoListViewController.swift
//  levesqu.a1
//
//  Created by Chris Levesque on 9/6/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import Foundation
import UIKit

class ToDoListViewController: UITableViewController {
    var toDoItems: [ToDoItem]

    required init(coder aDecoder: NSCoder) {
        toDoItems = [ToDoItem]()
        super.init(coder: aDecoder)
        
    }
   
    override func viewDidAppear(animated: Bool) {
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.LoadIntialData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    func LoadIntialData(){
        
        var item1 = ToDoItem()
        item1.itemName = "Buy Milk"
        self.toDoItems.append(item1)
        
        var item2 = ToDoItem()
        item2.itemName = "Mow The Lawn"
        self.toDoItems.append(item2)
        
        var item3 = ToDoItem()
        item3.itemName = "Read a Book"
        self.toDoItems.append(item3)
        
    }
    
    @IBAction func unwindToDoList(segue:UIStoryboardSegue){        
        var source: AddToDoItemController = segue.sourceViewController as! AddToDoItemController
        var item = source.toDoItem
        self.toDoItems.append(item)
        self.tableView.reloadData()
       
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDoItems.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCellWithIdentifier("ListPrototypeCell", forIndexPath: indexPath) as! UITableViewCell
        cell.textLabel?.text = self.toDoItems[indexPath.row].itemName as String
    
        
        if (toDoItems[indexPath.row].completed) {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
    
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //deselect row right after selecting
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        //toggle the completeion of he item selected
        var tappedItem = self.toDoItems[indexPath.row]
        tappedItem.completed = !tappedItem.completed
        
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        
        
    }
}
