//
//  addToDoItemController.swift
//  levesqu.a1
//
//  Created by Chris Levesque on 9/3/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import Foundation
import UIKit

class AddToDoItemController: UIViewController {
    
    
    var toDoItem: ToDoItem
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!

    
    required init(coder aDecoder: NSCoder) {
        toDoItem = ToDoItem()
        super.init(coder: aDecoder)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
               }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
            }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(sender!.isEqual(self.saveButton)){
            if(self.textField.text.isEmpty){
                return
            }
            else if(!self.textField.text.isEmpty){
                self.toDoItem.itemName = self.textField.text;
                self.toDoItem.completed = false;
            }
        }
    }

}