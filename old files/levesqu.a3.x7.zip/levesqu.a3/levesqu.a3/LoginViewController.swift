//
//  ViewController.swift
//  levesqu.a3
//
//  Created by Chris Levesque on 10/8/15.
//  Copyright © 2015 Chris Levesque. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    var username = ""
    var password = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButtonPresed(sender: UIButton) {
        username = usernameField.text!
        password = passwordField.text!
        
    }
    
    @IBAction func cancelButtonPressed(sender: AnyObject) {
        usernameField.text = ""
        passwordField.text = ""
    }
    
    
    @IBAction func newToAppButtonPressed(sender: UIButton) {
        let alert = UIAlertController(title: "New to This App", message:"In this iteration of the app I have added a feature to save the patient info the user inputs. As well as the patients room numberthey are staying in and the nurse assigned to them.", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok Cool", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)

        
    }
}

