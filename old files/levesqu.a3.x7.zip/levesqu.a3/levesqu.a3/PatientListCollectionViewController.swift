//
//  PatientListCollectionViewController.swift
//  levesqu.a3
//
//  Created by Chris Levesque on 10/9/15.
//  Copyright © 2015 Chris Levesque. All rights reserved.
//

import UIKit
import CoreData

private let reuseIdentifier = "Cell"

class PatientListCollectionViewController: UICollectionViewController {

    
    var patients = [NSManagedObject]()
    var rooms = [NSManagedObject]()
    var nurses = [NSManagedObject]()
    //var patients = [String] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //patients = ["Robert","Chris","Kevin","Ella"]

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        self.collectionView!.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        //1
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //2
        let fetchRequest = NSFetchRequest(entityName: "Patient")
        
        //3
        do {
            let results =
            try managedContext.executeFetchRequest(fetchRequest)
            patients = results as! [NSManagedObject]
            patients = results as! [NSManagedObject]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }

        
        let fetchRequest2 = NSFetchRequest(entityName: "Room")
        
        //3
        do {
            let results2 =
            try managedContext.executeFetchRequest(fetchRequest2)
            rooms = results2 as! [NSManagedObject]
            rooms = results2 as! [NSManagedObject]
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
        //2
        let fetchRequest3 = NSFetchRequest(entityName: "Nurse")
        
        //3
        do {
            let results3 =
            try managedContext.executeFetchRequest(fetchRequest3)
            nurses = results3 as! [NSManagedObject]
            nurses = results3 as! [NSManagedObject]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return patients.count
    }

    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("patientCell", forIndexPath: indexPath)
    
        // Configure the cell
        let patient = patients[indexPath.row]
        let room = rooms[indexPath.row]
        let nurse = nurses[indexPath.row]
        
        let nameLabel = cell.viewWithTag(1) as! UILabel
        let patientName = patient.valueForKey("patientName") as? String
        nameLabel.text = "Patient Name: " + patientName!
        
        let roomLabel = cell.viewWithTag(2) as! UILabel
        let roomNumber = room.valueForKey("roomNumber") as? String
        roomLabel.text = "Room Number: " + roomNumber!
        
        let nurseLabel = cell.viewWithTag(3) as! UILabel
        let nurseName = nurse.valueForKey("NurseName") as? String
        nurseLabel.text = "Nurse Name: " + nurseName!
    
        return cell
    }

    
    @IBAction func addPatient(sender: AnyObject) {

        let alert = UIAlertController(title: "Add New Patient", message: "Enter Name, Room Number, and Assigned Nurse", preferredStyle: .Alert)
    
        let saveAction = UIAlertAction(title: "Save",
            style: .Default,
            handler: { (action:UIAlertAction) -> Void in
                
                let nameField = alert.textFields!.first
                let roomField = alert.textFields![1]
                let nurseField = alert.textFields!.last
                self.savePatient(nameField!.text!, roomNumber: roomField.text! , nurseName: nurseField!.text!)
                self.collectionView?.reloadData()
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Default){(action: UIAlertAction) -> Void in
        }
        
        alert.addTextFieldWithConfigurationHandler{ textField -> Void in
            textField.placeholder = "Patient Name"
        }
        
        alert.addTextFieldWithConfigurationHandler{ textField -> Void in
            textField.placeholder = "Room Number"
        }
        
        alert.addTextFieldWithConfigurationHandler{ textField -> Void in
            textField.placeholder = "Assigned Nurse"
        }
        
        //alert.addTextFieldWithConfigurationHandler{(textField:UITextField) -> Void in}

        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        presentViewController(alert, animated: true, completion: nil)
    }
    
    
    func savePatient(patientName: String, roomNumber: String, nurseName: String) {
        //1
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //2 make entities for the objects
        let patientEntity =  NSEntityDescription.entityForName("Patient", inManagedObjectContext:managedContext)
        
        let roomEntity =  NSEntityDescription.entityForName("Room", inManagedObjectContext:managedContext)
        
        let nurseEntity =  NSEntityDescription.entityForName("Nurse", inManagedObjectContext:managedContext)
        
        
        // create objects and relationships
        let patient = NSManagedObject(entity: patientEntity!, insertIntoManagedObjectContext: managedContext)
        let roomObject = NSManagedObject(entity: roomEntity!,insertIntoManagedObjectContext: managedContext)
        let nurse = NSManagedObject(entity: nurseEntity!,insertIntoManagedObjectContext: managedContext)

        //3 set the attributes and relationships
        patient.setValue(patientName, forKey: "patientName")
        
        roomObject.setValue(roomNumber, forKey: "roomNumber")
        nurse.setValue(nurseName, forKey: "nurseName")
       
        // let manyRelation = patient.valueForKeyPath("room") as! NSMutableSet
        //manyRelation.addObject(roomObject)
        
        //relationships
       // patient.setValue(roomObject, forKeyPath: "roomNumber")
        //roomObject.setValue(patient, forKeyPath: "patient")
       // patient.setValue(nurse, forKey: "nurseName")
        
        //room.setValue(patient, forKey: "patient")
        
              
        //4 catch any problems
        do {
            try managedContext.save()
            //5
            patients.append(patient)
            rooms.append(roomObject)
            nurses.append(nurse)
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    
    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(collectionView: UICollectionView, shouldHighlightItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(collectionView: UICollectionView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(collectionView: UICollectionView, shouldShowMenuForItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, canPerformAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, performAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) {
    
    }
    */

}
