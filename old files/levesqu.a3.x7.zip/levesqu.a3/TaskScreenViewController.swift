//
//  TaskScreenViewController.swift
//  levesqu.a3
//
//  Created by Chris Levesque on 10/9/15.
//  Copyright © 2015 Chris Levesque. All rights reserved.
//

import UIKit

class TaskScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func needToKNowButtonPressed(sender: AnyObject) {
        
        let alert = UIAlertController(title: "Things you Need to Know", message:"The patient List is a UICollectionView, My intent is to have 3 columns to have the patient, their room number, and assigned nurse in each column. My Next Step will be to add a feature where a nurse can assined a piece of equipment to them.", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Good to Know", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
