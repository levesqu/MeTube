//
//  Nurse.swift
//  levesqu.a3
//
//  Created by Chris Levesque on 10/9/15.
//  Copyright © 2015 Chris Levesque. All rights reserved.
//

import Foundation
import CoreData


@objc(Nurse)
class Nurse: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

    @NSManaged var nurseName: String
}
