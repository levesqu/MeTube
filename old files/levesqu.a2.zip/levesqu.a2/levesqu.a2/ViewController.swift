//
//  ViewController.swift
//  levesqu.a2
//
//  Created by Chris Levesque on 9/21/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var isTyping: Bool
   
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    required init(coder aDecoder: NSCoder) {
        isTyping = false
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func loginPressed(sender: UIButton) {
        
        
    }
    
    
    @IBAction func cancel(sender: UIButton) {
        username.text = " "
        password.text = " "
        
    }
    @IBAction func dontAlert(sender: UIButton) {
        var alert = UIAlertController(title: "Alert", message: "I TOLD YOU NOT TO TOUGH THAT! LOOK NOW I'M YELLING AT YOU", preferredStyle: UIAlertControllerStyle.Alert)
    alert.addAction(UIAlertAction(title: "Stop the yelling man", style: UIAlertActionStyle.Default, handler: nil))
    self.presentViewController(alert, animated: true, completion: nil)

    }
}

