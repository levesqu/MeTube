//
//  PatientTableViewController.swift
//  levesqu.a2
//
//  Created by Chris Levesque on 9/22/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import UIKit

class PatientTableViewController: UITableViewController {
    
    var patients: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
     //   self.loadIntialData()
        self.tableView.editing = true
    }
    
     required init!(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
        patients = ["Greg Smith", "Kate West", "Dabo Swinney", "Rob Dyrdek", "Nathan Jones"]
    }

    /*func loadIntialData(){
        patients = ["Greg Smith", "Kate West", "Dabo Swinney", "Rob Dyrdek", "Nathan Jones"]
    }*/
    
    
    override func viewDidAppear(animated: Bool) {
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patients.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("PatientCell", forIndexPath: indexPath) as! UITableViewCell
        cell.textLabel?.text = patients[indexPath.row]
        return cell
    }
    
    override func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        return .None
    }
    
    override func tableView(tableView: UITableView, shouldIndentWhileEditingRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return false
    }
    
    override func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath) {
        let movedObject = self.patients[sourceIndexPath.row]
        patients.removeAtIndex(sourceIndexPath.row)
        patients.insert(movedObject, atIndex: destinationIndexPath.row)
        
    }
    
    
    // to save the new patient name, also make sure you connect the cancel and save buttons to the exit
    @IBAction func unwindToDoList(sender: UIStoryboardSegue){
        if let source = sender.sourceViewController as? AddPatientViewController, let item = source.patient.patientsName{
            //var item = source.patient.patientsName!
            let newIndexPath = NSIndexPath(forRow: patients.count, inSection: 0)
            patients.append(item)
            tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom)
        }
    }


}


