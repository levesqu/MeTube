//
//  AddPatientViewController.swift
//  levesqu.a2
//
//  Created by Chris Levesque on 9/23/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import UIKit

class AddPatientViewController: UIViewController, UITextFieldDelegate {

    //@IBOutlet weak var savePatient: UIBarButtonItem!
    @IBOutlet weak var patientName: UITextField!
    @IBOutlet weak var savePatient: UIBarButtonItem!
    
    var patient: Patient
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //patientName.delegate = self
        patientName.delegate = self
        
        var alert = UIAlertController(title: "Alert", message: "In the future Patients and their attributes will be loaded from an already filled database.", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
        
        //checkValidPatientName()
        
        
        // Do any additional setup after loading the view.
    }
    
    required init(coder aDecoder: NSCoder) {
        patient = Patient()
        super.init(coder: aDecoder)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
   /* func textFieldDidBeginEditing(textField: UITextField) {
        // Disable the Save button while editing.
        savePatient.enabled = false
    }*/
    
    /*func checkValidPatientName() {
        // Disable the Save button if the text field is empty.
        //let text = patientName.text ?? ""
        //savePatient.enabled = !text.isEmpty
    }*/
    
    /*func textFieldDidEndEditing(textField: UITextField) {
        checkValidPatientName()
        navigationItem.title = patientName.text
    }*/
   
    // MARK: - Navigation
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(savePatient === sender){
            let name = patientName.text ?? ""
            patient = Patient(name: name)
        }
    }
    
    @IBAction func cancel(sender: UIBarButtonItem) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    }
    
   
 /*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    


