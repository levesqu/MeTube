//
//  Patient.swift
//  levesqu.a2
//
//  Created by Chris Levesque on 9/23/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import UIKit

class Patient: NSObject {
   
    var patientsName: String?
    
    override init() {
        patientsName = " "
    }
    
    init(name: String){
        patientsName = name
        
    }
}
