//
//  ViewController.swift
//  Calculator
//
//  Created by Chris Levesque on 6/16/15.
//  Copyright (c) 2015 Chris Levesque. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var display: UILabel!
    @IBOutlet weak var operandList: UILabel!
    
    var operandStack = Array<Double>()
    var userIsInTheMiddleOfTypingANumber = false
    
    @IBAction func appendDigit(sender: UIButton) {
        let digit = sender.currentTitle!
        
        if userIsInTheMiddleOfTypingANumber{
            if (display.text?.rangeOfString(".") == nil){
                display.text = display.text! + digit
            }
            else{
                if digit.rangeOfString(".") == nil {
                    display.text =  display.text! + digit
                }
            }
        }
        else{
            display.text =  digit
            userIsInTheMiddleOfTypingANumber = true
        }
        
    }
    
    @IBAction func enter() {
        userIsInTheMiddleOfTypingANumber = false
        operandStack.append(displayValue)
        println("\(operandStack)")
        trackHistory(display.text!)
    }
    
    
    var displayValue: Double {
        get {
            return NSNumberFormatter().numberFromString(display.text!)!.doubleValue
            
        }
        set {
            display.text = "\(newValue)"
            userIsInTheMiddleOfTypingANumber = false
        }

    }
    func trackHistory(next: String) {
        operandList.text = operandList.text! + next + " "
        
    }

    @IBAction func operate(sender: UIButton) {
        let operation = sender.currentTitle!
        if userIsInTheMiddleOfTypingANumber {
            trackHistory(operation)
            enter()
            
        }
        switch operation{
            case"x": performOperation(){ ($0 * $1)}
            case"÷": performOperation(){ $1 / $0 }
            case"+": performOperation(){ $0 + $1 }
            case"-": performOperation(){ $1 - $0 }
            case"√": performOperation(){ sqrt($0)}
            case"π": performOperation(){M_PI}
            case"cos": performOperation(){cos($0)}
            case"sin": performOperation(){sin($0)}
            
        default: break
            
        }
    }
    
    func performOperation(operation:(Double, Double)-> Double){
        if (operandStack.count >= 2) {
            displayValue = round(1000000*operation(operandStack.removeLast(), operandStack.removeLast()))/1000000
            trackHistory("=")
            enter()
        }
    }
    
    private func performOperation(operation: Double -> Double){
        if operandStack.count >= 1 {
            displayValue = round(1000000*operation(operandStack.removeLast()))/1000000
            trackHistory("=")
            enter()
        }
    }
    private func performOperation(operation: () -> Double){
        if operandStack.count >= 0 {
            displayValue = round(1000000*M_PI)/1000000
            
            enter()
            
        }
    }
    
    
    @IBAction func clear(sender: UIButton) {
        userIsInTheMiddleOfTypingANumber = false
        display.text = "0"
        operandList.text = " "
        operandStack.removeAll(keepCapacity: false)
    }

    
}

